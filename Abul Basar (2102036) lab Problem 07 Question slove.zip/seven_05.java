public class seven_05 {
    public static void main(String[] args) {
         
    }
}
