public class Lab12_30 {
public static void main(String[] args) {
    String str = "The Quick BroWn FoX!";

        String upper_str = str.toUpperCase();

        System.out.println("Original String: " + str);
        System.out.println("String in uppercase: " + upper_str);
}
}
