public class Lab12_29 {
public static void main(String[] args) {
    String str = "The Quick BroWn FoX!";

    String lowerStr = str.toLowerCase();

    System.out.println("Original String: " + str);
    System.out.println("String in lowercase: " + lowerStr);
}
}
