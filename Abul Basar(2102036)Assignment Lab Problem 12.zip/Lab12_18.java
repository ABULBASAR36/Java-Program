public class Lab12_18 {
public static void main(String[] args) {
    String str = "Python Exercises.";

        int hash_code = str.hashCode();

        System.out.println("The hash for " + str +
            " is " + hash_code);
}
}
