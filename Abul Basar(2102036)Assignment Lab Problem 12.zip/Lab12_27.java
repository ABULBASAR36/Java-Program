public class Lab12_27 {
public static void main(String[] args) {
    String str = "The quick brown fox jumps over the lazy dog.";

        String new_str = str.substring(10, 26);

        System.out.println("old = " + str);
        System.out.println("new = " + new_str);
}
}
