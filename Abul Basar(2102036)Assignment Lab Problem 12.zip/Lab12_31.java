public class Lab12_31 {
public static void main(String[] args) {
    String str = " Java Exercises ";

    String new_str = str.trim();

    System.out.println("Original String: " + str);
    System.out.println("New String: " + new_str);
}
}
