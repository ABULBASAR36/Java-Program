public class Lab12_22 {
public static void main(String[] args) {
    
    String str = "example.com";
        
        int len = str.length();
        
        System.out.println("The string length of '" + str + "' is: " + len);
}
}
